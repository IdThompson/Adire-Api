package com.decagon.adire.service;

import com.decagon.adire.dto.request.LoginDTO;
import org.springframework.stereotype.Service;


public interface DesignerService {
   String designerlogin(LoginDTO loginDTO);
}
