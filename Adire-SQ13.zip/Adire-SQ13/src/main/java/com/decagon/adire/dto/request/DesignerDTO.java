package com.decagon.adire.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DesignerDTO {
    private String firstName;
    private  String lastName;
    private String email;
    private  int phoneNumber;
    private  String password;
    private  String confirmPassword;


}
