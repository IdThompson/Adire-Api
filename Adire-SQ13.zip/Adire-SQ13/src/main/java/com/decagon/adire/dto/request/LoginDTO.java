package com.decagon.adire.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginDTO {
    private  String email;
    private String password;
}
