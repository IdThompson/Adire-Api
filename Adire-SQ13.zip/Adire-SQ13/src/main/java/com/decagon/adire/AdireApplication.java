package com.decagon.adire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdireApplication {

    public static void main(String[] args) {SpringApplication.run(AdireApplication.class, args);
    }

}
