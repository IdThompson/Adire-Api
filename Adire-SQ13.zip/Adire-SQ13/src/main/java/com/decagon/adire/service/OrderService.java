package com.decagon.adire.service;

import org.springframework.stereotype.Service;

@Service
public interface OrderService {
}
