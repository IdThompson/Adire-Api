package com.decagon.adire.service;

import com.decagon.adire.dto.request.DesignerDTO;

public interface UserService {

    DesignerDTO registerUser(DesignerDTO designerDTO);
}
