package com.decagon.adire.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.stream.DoubleStream;

@Getter
@AllArgsConstructor
public enum Role {
   DESIGNER,
    CUSTOMER;


}
